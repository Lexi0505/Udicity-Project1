import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

outgoing_calls = []
incoming_calls = []
text_nums =[]
for call in calls:
    if call[0] not in outgoing_calls:
        outgoing_calls.append(call[0])
    if call[1] not in incoming_calls:
        incoming_calls.append(call[1])

for text in texts:
    if text[0] not in text_nums:
        text_nums.append(text[0])
    if text[1] not in text_nums:
        text_nums.append(text[1])

temps = list(set(outgoing_calls)^set(incoming_calls))
telemarketers = list(set(temps)^set(text_nums))
print("These numbers could be telemarketers:")
print('\n'.join(sorted(telemarketers)))
