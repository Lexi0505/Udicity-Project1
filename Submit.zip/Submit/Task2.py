import csv

num_time = {}
def calc_time(num,time):
    if '{}'.format(num) not in num_time:
        num_time['{}'.format(num)] = time
    else:
        num_time['{}'.format(num)] = num_time.get('{}'.format(num)) + time

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

for call in calls:
    calc_time(call[0],call[3])
    calc_time(call[1],call[3])

temp_dict = sorted(num_time.items(),key = lambda x:x[1])

print("{} spent the longest time, {} seconds, on the phone during September 2016.".format(temp_dict[-1][0],temp_dict[-1][1]))
