import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)
    text_nums = set()
    for text in texts:
        text_nums.add(text[0])
        text_nums.add(text[1])


with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
    call_nums = set()
    for call in calls:
        call_nums.add(call[0])
        call_nums.add(call[1])
count = len(text_nums.union(call_nums))
print("There are {} different telephone numbers in the records.".format(count))
